# COMP9417 Project 解决思路规划

## 一、项目概览

**目标**: 撰写4-6页技术报告，对xRFM算法进行实验分析，与XGBoost等baseline对比。

**核心交付物**:
1. PDF报告 (4-6页正文 + 标题页 + 参考文献)
2. 可复现的代码压缩包
3. Peer review (5月1日前)

**截止日期**: 4月29日 5pm

---

## 二、数据集选择策略

### 约束条件
- ≥5个数据集 (≥2回归, ≥2分类)
- ≥1个 n > 10,000
- ≥1个 d > 50
- ≥1个 mixed feature types
- **不能**复用xRFM论文中的数据集

### 论文中已用数据集 (必须避免)
California Housing, Covertype, NYC Taxi Tipping, Breast Cancer Wisconsin,
Airlines DepDelay, Allstate Claims, Black Friday, Buzzinsocialmedia,
wave energy, Yolanda, Higgs, jannis, MiniBooNE, numerai28.6,
porto-seguro, dionis, Fashion-MNIST, kick

### 选定数据集

| # | 数据集 | 任务 | n | d | 混合类型 | 满足条件 |
|---|--------|------|-------|-----|---------|---------|
| 1 | Adult Income (UCI) | 二分类 | ~48,842 | 14 | ✓ 数值+类别 | n>10k, mixed |
| 2 | Spambase (UCI) | 二分类 | 4,601 | 57 | ✗ 全数值 | d>50 |
| 3 | Dry Bean (UCI) | 多分类 | 13,611 | 16 | ✗ 全数值 | n>10k |
| 4 | Superconductivity (UCI) | 回归 | 21,263 | 81 | ✗ 全数值 | n>10k, d>50 |
| 5 | Concrete Strength (UCI) | 回归 | 1,030 | 8 | ✗ 全数值 | 小数据集 |
| 6 | Bike Sharing (UCI) | 回归 | 17,379 | 12 | ✓ 数值+类别 | n>10k, mixed |

**选择理由**:
- Adult Income: 经典mixed-type分类任务，大规模，测试xRFM处理类别特征能力
- Spambase: 高维二分类，测试xRFM在d>50时的特征选择能力
- Dry Bean: 多分类任务，中等规模，7类
- Superconductivity: 高维回归，用于scaling实验
- Concrete: 小数据集回归，测试xRFM在小样本上的表现
- Bike Sharing: 中等回归，有时间/季节等类别特征

---

## 三、实验设计

### 3.1 模型配置
- **xRFM**: 使用官方库 `pip install xrfm`，sklearn兼容API
- **XGBoost**: `xgboost.XGBClassifier/XGBRegressor`
- **Random Forest**: `sklearn.ensemble.RandomForestClassifier/Regressor`
- **MLP**: `sklearn.neural_network.MLPClassifier/MLPRegressor`

### 3.2 数据划分
- Train/Val/Test = 60/20/20 (stratified for classification)
- 固定 random_seed=42
- 在validation set上调参，test set只报告最终结果

### 3.3 超参调优
使用 Optuna 或 GridSearch:
- **xRFM**: 主要调 reg (正则化), bandwidth, kernel type
- **XGBoost**: n_estimators, max_depth, learning_rate, subsample
- **Random Forest**: n_estimators, max_depth, min_samples_split
- **MLP**: hidden_layer_sizes, learning_rate, alpha

### 3.4 评估指标
- 回归: RMSE
- 分类: Accuracy, AUC-ROC (binary) / AUC-ROC macro (multi-class)
- 所有模型: Training time, Inference time per sample

### 3.5 特殊实验

#### A. 可解释性对比 (选 Adult Income 或 Spambase)
在同一数据集上提取:
1. xRFM AGOP 对角线 → 特征重要性
2. PCA loadings
3. Mutual Information scores
4. Permutation Importance (基于XGBoost)

比较哪些特征被不同方法认为重要，分析一致性和差异。

#### B. Scaling实验 (选 Superconductivity, n=21k)
子采样训练集: n ∈ {500, 1000, 2000, 5000, 10000, 15000, 全量}
绘制:
- Test RMSE vs n (所有模型)
- Training time vs n (所有模型)

#### C. Bonus: 手动实现AGOP splitting
在小数据集上:
1. 训练一个kernel model
2. 计算梯度 ∇f(x_i)
3. 计算 AGOP = (1/n) Σ ∇f ∇f^T
4. 提取AGOP最大特征向量
5. 与xRFM库的split方向对比

---

## 四、报告结构 (LaTeX)

### 标题页 (不计入页数)
- 项目标题 + "+bonus"
- 组名、成员姓名和zID

### 1. Introduction (0.5页)
- 表格数据的重要性和挑战
- 为什么GBDT一直称霸
- xRFM的核心思路：feature-learning kernel + tree
- 我们的实验概述

### 2. Methodology (1.5-2页)
**2.1 AGOP理论**
- 形式化定义 (Eq. 2 from paper)
- 几何直觉：梯度协方差，捕获预测函数变化最大的方向
- 对角线 vs 特征向量的区别
- 与PCA/MI/Permutation Importance对比

**2.2 xRFM算法**
- 完整pipeline: tree splitting → leaf RFM training → inference
- 计算复杂度: O(n log n) training, O(log n) inference
- 解决的根本限制

**2.3 实验设置**
- 数据集描述
- 数据预处理
- 模型配置和调参
- 评估指标

### 3. Results (1-1.5页)
- 主结果表 (所有数据集 × 所有模型 × 所有指标)
- 可解释性对比图
- Scaling曲线图
- 训练/推理时间对比

### 4. Discussion (0.75-1页)
- xRFM在哪里赢了/输了，为什么
- 可解释性方法的一致性分析
- xRFM不如XGBoost的场景和假设
- 改进方向

### 5. Conclusion (0.25-0.5页)
- 关键发现总结

### References
- xRFM paper, RFM paper, XGBoost paper, etc.

### Appendix (不计入页数)
- Bonus: AGOP splitting实现
- 额外图表

---

## 五、时间规划

| 阶段 | 任务 | 预计时间 |
|------|------|---------|
| 1 | 环境搭建 + 数据下载 | 0.5天 |
| 2 | 实验代码编写 + 调试 | 2天 |
| 3 | 运行全部实验 | 1天 |
| 4 | 可解释性 + Scaling实验 | 1天 |
| 5 | Bonus实现 | 0.5天 |
| 6 | 报告撰写 | 2天 |
| 7 | 审校 + 提交 | 0.5天 |

---

## 六、注意事项

1. **不使用论文中的数据集** - 这是硬性要求
2. **所有random seed固定为42** - 可复现性
3. **在validation上调参，test只报最终结果**
4. **类别特征需要one-hot编码后再传给xRFM** - 不能传raw strings
5. **图表需要放在正文中**，不能全放appendix
6. **代码需有README** 说明如何运行
