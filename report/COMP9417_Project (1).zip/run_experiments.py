"""
COMP9417 Project: xRFM Feature Learning Kernel Machines for Tabular Data
Main experiment runner.

Usage:
    python run_experiments.py          # Run all experiments
    python run_experiments.py --quick  # Quick test run with smaller search
"""

import os
import sys
import json
import time
import warnings
import argparse
import numpy as np
import pandas as pd
from pathlib import Path

warnings.filterwarnings('ignore')
np.random.seed(42)

# ============================================================
# Configuration
# ============================================================
RANDOM_STATE = 42
RESULTS_DIR = Path("results")
FIGURES_DIR = Path("figures")
RESULTS_DIR.mkdir(exist_ok=True)
FIGURES_DIR.mkdir(exist_ok=True)


# ============================================================
# Dataset Loading
# ============================================================
def load_adult_income():
    """Adult Income dataset - binary classification, mixed features, n~48k."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('adult', version=2, as_frame=True, parser='auto')
    X, y = data.data, data.target
    # Encode target
    y = (y == '>50K').astype(int) if y.dtype == object else y
    # Handle categorical columns
    cat_cols = X.select_dtypes(include=['category', 'object']).columns.tolist()
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    return X, y, 'classification', 'Adult Income', cat_cols, num_cols


def load_spambase():
    """Spambase dataset - binary classification, d=57."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('spambase', version=1, as_frame=True, parser='auto')
    X, y = data.data, data.target.astype(int)
    return X, y, 'classification', 'Spambase', [], X.columns.tolist()


def load_dry_bean():
    """Dry Bean dataset - multiclass classification, n=13611."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('dry-bean-dataset', version=1, as_frame=True, parser='auto')
    X, y = data.data, data.target
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    y = pd.Series(le.fit_transform(y), name='target')
    return X, y, 'classification', 'Dry Bean', [], X.columns.tolist()


def load_superconductivity():
    """Superconductivity dataset - regression, d=81, n=21263."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('superconduct', version=1, as_frame=True, parser='auto')
    X, y = data.data, data.target.astype(float)
    return X, y, 'regression', 'Superconductivity', [], X.columns.tolist()


def load_concrete():
    """Concrete Compressive Strength - regression, n=1030."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('concrete', version=1, as_frame=True, parser='auto')
    X, y = data.data, data.target.astype(float)
    return X, y, 'regression', 'Concrete Strength', [], X.columns.tolist()


def load_bike_sharing():
    """Bike Sharing dataset - regression, n~17k, mixed features."""
    from sklearn.datasets import fetch_openml
    data = fetch_openml('Bike_Sharing_Demand', version=2, as_frame=True, parser='auto')
    X, y = data.data, data.target.astype(float)
    cat_cols = X.select_dtypes(include=['category', 'object']).columns.tolist()
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    return X, y, 'regression', 'Bike Sharing', cat_cols, num_cols


DATASET_LOADERS = {
    'adult': load_adult_income,
    'spambase': load_spambase,
    'dry_bean': load_dry_bean,
    'superconductivity': load_superconductivity,
    'concrete': load_concrete,
    'bike_sharing': load_bike_sharing,
}


# ============================================================
# Preprocessing
# ============================================================
def preprocess_data(X, y, cat_cols, num_cols, task, test_size=0.2, val_size=0.2):
    """Preprocess: handle missing values, encode categoricals, split data."""
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer

    X = X.copy()
    y = y.copy()

    # Drop rows with missing target
    mask = y.notna()
    X = X[mask].reset_index(drop=True)
    y = y[mask].reset_index(drop=True)

    # Identify columns
    if not cat_cols and not num_cols:
        num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
        cat_cols = [c for c in X.columns if c not in num_cols]

    # Build preprocessor
    transformers = []
    if num_cols:
        num_pipe = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        transformers.append(('num', num_pipe, num_cols))
    if cat_cols:
        cat_pipe = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
        ])
        transformers.append(('cat', cat_pipe, cat_cols))

    preprocessor = ColumnTransformer(transformers)

    # Stratify for classification
    stratify = y if task == 'classification' else None

    # Split: first train+val vs test
    X_trainval, X_test, y_trainval, y_test = train_test_split(
        X, y, test_size=test_size, random_state=RANDOM_STATE, stratify=stratify
    )
    # Then train vs val
    stratify_tv = y_trainval if task == 'classification' else None
    val_ratio = val_size / (1 - test_size)
    X_train, X_val, y_train, y_val = train_test_split(
        X_trainval, y_trainval, test_size=val_ratio,
        random_state=RANDOM_STATE, stratify=stratify_tv
    )

    # Fit preprocessor on train only
    X_train_p = preprocessor.fit_transform(X_train)
    X_val_p = preprocessor.transform(X_val)
    X_test_p = preprocessor.transform(X_test)

    # Get feature names
    feature_names = []
    if num_cols:
        feature_names.extend(num_cols)
    if cat_cols:
        ohe = preprocessor.named_transformers_['cat'].named_steps['onehot']
        feature_names.extend(ohe.get_feature_names_out(cat_cols).tolist())

    return (X_train_p, X_val_p, X_test_p,
            np.array(y_train), np.array(y_val), np.array(y_test),
            feature_names, preprocessor)


# ============================================================
# Model Training & Evaluation
# ============================================================
def get_models(task, quick=False):
    """Return dict of model name -> model instance."""
    models = {}

    # --- xRFM ---
    try:
        from xrfm import xRFMRegressor, xRFMClassifier
        if task == 'regression':
            models['xRFM'] = xRFMRegressor(random_state=RANDOM_STATE)
        else:
            models['xRFM'] = xRFMClassifier(random_state=RANDOM_STATE)
    except ImportError:
        print("WARNING: xrfm not installed. Run: pip install xrfm")

    # --- XGBoost ---
    from xgboost import XGBClassifier, XGBRegressor
    if task == 'regression':
        models['XGBoost'] = XGBRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=6,
            subsample=0.8, colsample_bytree=0.8,
            random_state=RANDOM_STATE, verbosity=0
        )
    else:
        models['XGBoost'] = XGBClassifier(
            n_estimators=500, learning_rate=0.05, max_depth=6,
            subsample=0.8, colsample_bytree=0.8,
            random_state=RANDOM_STATE, verbosity=0,
            use_label_encoder=False, eval_metric='logloss'
        )

    # --- Random Forest ---
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    if task == 'regression':
        models['Random Forest'] = RandomForestRegressor(
            n_estimators=300, max_depth=None,
            random_state=RANDOM_STATE, n_jobs=-1
        )
    else:
        models['Random Forest'] = RandomForestClassifier(
            n_estimators=300, max_depth=None,
            random_state=RANDOM_STATE, n_jobs=-1
        )

    # --- MLP ---
    from sklearn.neural_network import MLPClassifier, MLPRegressor
    if task == 'regression':
        models['MLP'] = MLPRegressor(
            hidden_layer_sizes=(128, 64), max_iter=500,
            early_stopping=True, random_state=RANDOM_STATE
        )
    else:
        models['MLP'] = MLPClassifier(
            hidden_layer_sizes=(128, 64), max_iter=500,
            early_stopping=True, random_state=RANDOM_STATE
        )

    return models


def evaluate_model(model, X_train, y_train, X_test, y_test, task, model_name=''):
    """Train model, measure time, evaluate on test set."""
    from sklearn.metrics import (root_mean_squared_error, accuracy_score,
                                 roc_auc_score)

    # Training
    t0 = time.time()
    if model_name == 'xRFM':
        # xRFM may need special handling
        try:
            model.fit(X_train, y_train)
        except Exception as e:
            print(f"  xRFM fit error: {e}")
            return None
    else:
        model.fit(X_train, y_train)
    train_time = time.time() - t0

    # Inference
    t0 = time.time()
    y_pred = model.predict(X_test)
    infer_time = time.time() - t0
    infer_per_sample = infer_time / len(X_test)

    results = {
        'train_time': train_time,
        'infer_time': infer_time,
        'infer_per_sample': infer_per_sample,
    }

    if task == 'regression':
        rmse = root_mean_squared_error(y_test, y_pred)
        results['RMSE'] = rmse
    else:
        acc = accuracy_score(y_test, y_pred)
        results['Accuracy'] = acc
        # AUC-ROC
        try:
            if hasattr(model, 'predict_proba'):
                y_proba = model.predict_proba(X_test)
                n_classes = len(np.unique(y_test))
                if n_classes == 2:
                    auc = roc_auc_score(y_test, y_proba[:, 1])
                else:
                    auc = roc_auc_score(y_test, y_proba, multi_class='ovr', average='macro')
                results['AUC-ROC'] = auc
            else:
                results['AUC-ROC'] = None
        except Exception as e:
            print(f"  AUC-ROC error: {e}")
            results['AUC-ROC'] = None

    return results


# ============================================================
# Main Experiment Loop
# ============================================================
def run_main_experiments(quick=False):
    """Run all models on all datasets."""
    all_results = []

    for ds_key, loader in DATASET_LOADERS.items():
        print(f"\n{'='*60}")
        print(f"Dataset: {ds_key}")
        print(f"{'='*60}")

        try:
            X, y, task, ds_name, cat_cols, num_cols = loader()
        except Exception as e:
            print(f"  Failed to load {ds_key}: {e}")
            continue

        print(f"  Shape: {X.shape}, Task: {task}")

        (X_train, X_val, X_test,
         y_train, y_val, y_test,
         feature_names, preprocessor) = preprocess_data(
            X, y, cat_cols, num_cols, task
        )

        print(f"  Train: {X_train.shape}, Val: {X_val.shape}, Test: {X_test.shape}")

        # Combine train+val for final training (tune on val, then retrain on train+val)
        X_trainval = np.vstack([X_train, X_val])
        y_trainval = np.concatenate([y_train, y_val])

        models = get_models(task, quick=quick)

        for model_name, model in models.items():
            print(f"\n  Training {model_name}...")
            result = evaluate_model(
                model, X_trainval, y_trainval, X_test, y_test,
                task, model_name=model_name
            )
            if result is not None:
                result['dataset'] = ds_name
                result['model'] = model_name
                result['task'] = task
                result['n_train'] = len(X_trainval)
                result['n_features'] = X_train.shape[1]
                all_results.append(result)
                if task == 'regression':
                    print(f"    RMSE: {result['RMSE']:.4f}, "
                          f"Train: {result['train_time']:.2f}s")
                else:
                    print(f"    Acc: {result['Accuracy']:.4f}, "
                          f"AUC: {result.get('AUC-ROC', 'N/A')}, "
                          f"Train: {result['train_time']:.2f}s")

    df = pd.DataFrame(all_results)
    df.to_csv(RESULTS_DIR / 'main_results.csv', index=False)
    print(f"\nResults saved to {RESULTS_DIR / 'main_results.csv'}")
    return df


# ============================================================
# Interpretability Experiment
# ============================================================
def run_interpretability_experiment():
    """Compare AGOP vs PCA vs MI vs Permutation Importance on Spambase."""
    from sklearn.decomposition import PCA
    from sklearn.feature_selection import mutual_info_classif
    from sklearn.inspection import permutation_importance
    from xgboost import XGBClassifier

    print(f"\n{'='*60}")
    print("Interpretability Experiment: Spambase")
    print(f"{'='*60}")

    X, y, task, ds_name, cat_cols, num_cols = load_spambase()
    (X_train, X_val, X_test,
     y_train, y_val, y_test,
     feature_names, _) = preprocess_data(X, y, cat_cols, num_cols, task)

    X_trainval = np.vstack([X_train, X_val])
    y_trainval = np.concatenate([y_train, y_val])

    # 1. PCA loadings (absolute values of first component)
    print("  Computing PCA loadings...")
    pca = PCA(n_components=5, random_state=RANDOM_STATE)
    pca.fit(X_trainval)
    pca_importance = np.abs(pca.components_[0])

    # 2. Mutual Information
    print("  Computing Mutual Information...")
    mi_scores = mutual_info_classif(X_trainval, y_trainval, random_state=RANDOM_STATE)

    # 3. Permutation Importance (XGBoost)
    print("  Computing Permutation Importance (XGBoost)...")
    xgb = XGBClassifier(n_estimators=300, random_state=RANDOM_STATE, verbosity=0)
    xgb.fit(X_trainval, y_trainval)
    perm_imp = permutation_importance(xgb, X_test, y_test,
                                       n_repeats=10, random_state=RANDOM_STATE)
    perm_scores = perm_imp.importances_mean

    # 4. xRFM AGOP diagonal
    print("  Computing xRFM AGOP...")
    agop_scores = np.zeros(X_trainval.shape[1])
    try:
        from xrfm import xRFMClassifier
        xrfm_model = xRFMClassifier(random_state=RANDOM_STATE)
        xrfm_model.fit(X_trainval, y_trainval)
        # Extract AGOP from leaf models
        if hasattr(xrfm_model, 'tree_') or hasattr(xrfm_model, 'leaf_models_'):
            # Try to access AGOP matrices
            try:
                agops = xrfm_model.get_agop_diagonals()
                agop_scores = np.mean(agops, axis=0)
            except:
                # Alternative: access internal attributes
                try:
                    for leaf in xrfm_model.leaves_:
                        if hasattr(leaf, 'M_') and leaf.M_ is not None:
                            agop_scores += np.diag(leaf.M_)
                    agop_scores /= max(len(xrfm_model.leaves_), 1)
                except:
                    print("    Could not extract AGOP. Using feature importances if available.")
                    if hasattr(xrfm_model, 'feature_importances_'):
                        agop_scores = xrfm_model.feature_importances_
    except Exception as e:
        print(f"    xRFM AGOP extraction failed: {e}")

    # Normalize all to [0, 1]
    def normalize(arr):
        mn, mx = arr.min(), arr.max()
        return (arr - mn) / (mx - mn + 1e-12)

    results = pd.DataFrame({
        'feature': feature_names[:len(pca_importance)],
        'PCA': normalize(pca_importance),
        'MI': normalize(mi_scores),
        'Permutation': normalize(perm_scores),
        'AGOP': normalize(agop_scores) if agop_scores.sum() > 0 else agop_scores,
    })

    results.to_csv(RESULTS_DIR / 'interpretability_results.csv', index=False)

    # Plot top-15 features by each method
    plot_interpretability(results)

    return results


def plot_interpretability(results):
    """Create interpretability comparison figure."""
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    methods = ['AGOP', 'PCA', 'MI', 'Permutation']

    for ax, method in zip(axes.flat, methods):
        top15 = results.nlargest(15, method)
        ax.barh(range(len(top15)), top15[method].values, color='steelblue', alpha=0.8)
        ax.set_yticks(range(len(top15)))
        ax.set_yticklabels(top15['feature'].values, fontsize=8)
        ax.set_xlabel('Normalized Importance')
        ax.set_title(f'{method}')
        ax.invert_yaxis()

    plt.suptitle('Feature Importance Comparison on Spambase', fontsize=14)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / 'interpretability_comparison.pdf', bbox_inches='tight', dpi=150)
    plt.savefig(FIGURES_DIR / 'interpretability_comparison.png', bbox_inches='tight', dpi=150)
    plt.close()
    print(f"  Saved interpretability figure.")


# ============================================================
# Scaling Experiment
# ============================================================
def run_scaling_experiment():
    """Test performance vs training size on Superconductivity."""
    print(f"\n{'='*60}")
    print("Scaling Experiment: Superconductivity")
    print(f"{'='*60}")

    X, y, task, ds_name, cat_cols, num_cols = load_superconductivity()
    (X_train, X_val, X_test,
     y_train, y_val, y_test,
     feature_names, _) = preprocess_data(X, y, cat_cols, num_cols, task)

    X_trainval = np.vstack([X_train, X_val])
    y_trainval = np.concatenate([y_train, y_val])

    sample_sizes = [500, 1000, 2000, 5000, 10000, len(X_trainval)]
    model_names = ['xRFM', 'XGBoost', 'Random Forest', 'MLP']
    scaling_results = []

    for n in sample_sizes:
        print(f"\n  n = {n}")
        # Subsample
        if n < len(X_trainval):
            idx = np.random.RandomState(RANDOM_STATE).choice(
                len(X_trainval), size=n, replace=False
            )
            X_sub = X_trainval[idx]
            y_sub = y_trainval[idx]
        else:
            X_sub = X_trainval
            y_sub = y_trainval

        models = get_models(task)
        for model_name, model in models.items():
            print(f"    {model_name}...", end=' ')
            result = evaluate_model(model, X_sub, y_sub, X_test, y_test,
                                    task, model_name=model_name)
            if result:
                result['n'] = n
                result['model'] = model_name
                scaling_results.append(result)
                print(f"RMSE={result['RMSE']:.4f}, Time={result['train_time']:.2f}s")

    df = pd.DataFrame(scaling_results)
    df.to_csv(RESULTS_DIR / 'scaling_results.csv', index=False)
    plot_scaling(df)
    return df


def plot_scaling(df):
    """Plot scaling experiment results."""
    import matplotlib.pyplot as plt

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    for model_name in df['model'].unique():
        sub = df[df['model'] == model_name].sort_values('n')
        ax1.plot(sub['n'], sub['RMSE'], 'o-', label=model_name, markersize=5)
        ax2.plot(sub['n'], sub['train_time'], 'o-', label=model_name, markersize=5)

    ax1.set_xlabel('Training Set Size (n)')
    ax1.set_ylabel('Test RMSE')
    ax1.set_title('Test Performance vs Training Size')
    ax1.legend()
    ax1.set_xscale('log')
    ax1.grid(True, alpha=0.3)

    ax2.set_xlabel('Training Set Size (n)')
    ax2.set_ylabel('Training Time (s)')
    ax2.set_title('Training Time vs Training Size')
    ax2.legend()
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.grid(True, alpha=0.3)

    plt.suptitle('Scaling Analysis on Superconductivity Dataset', fontsize=13)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / 'scaling_experiment.pdf', bbox_inches='tight', dpi=150)
    plt.savefig(FIGURES_DIR / 'scaling_experiment.png', bbox_inches='tight', dpi=150)
    plt.close()
    print(f"  Saved scaling figure.")


# ============================================================
# Bonus: AGOP Splitting from Scratch
# ============================================================
def run_bonus_agop():
    """Implement AGOP-based splitting from scratch and compare with library."""
    print(f"\n{'='*60}")
    print("Bonus: AGOP Splitting from Scratch")
    print(f"{'='*60}")

    from sklearn.datasets import fetch_openml

    # Use Concrete (small dataset)
    X, y, task, ds_name, cat_cols, num_cols = load_concrete()
    (X_train, _, _, y_train, _, _, feature_names, _) = preprocess_data(
        X, y, cat_cols, num_cols, task
    )

    # Subsample for speed
    n = min(500, len(X_train))
    X_sub = X_train[:n]
    y_sub = y_train[:n]

    print(f"  Using {n} samples, {X_sub.shape[1]} features")

    # --- Manual AGOP computation ---
    from scipy.spatial.distance import cdist

    def laplace_kernel(X1, X2, bandwidth=1.0):
        """Compute Laplace kernel matrix."""
        dists = cdist(X1, X2, metric='euclidean')
        return np.exp(-dists / bandwidth)

    def compute_kernel_regression(X, y, bandwidth=1.0, reg=1e-3):
        """Fit kernel ridge regression, return alpha coefficients."""
        K = laplace_kernel(X, X, bandwidth)
        alpha = np.linalg.solve(K + reg * np.eye(len(K)), y)
        return alpha

    def compute_gradients(X, alpha, bandwidth=1.0):
        """Compute gradients of kernel predictor at each training point."""
        n, d = X.shape
        grads = np.zeros((n, d))
        for i in range(n):
            # ∇_x f(x_i) = Σ_j α_j ∇_x K(x_i, x_j)
            # For Laplace: ∇_x K(x,z) = K(x,z) * (z-x) / (L * ||x-z||)
            for j in range(n):
                if i == j:
                    continue  # Skip self (non-differentiable)
                diff = X[j] - X[i]
                dist = np.linalg.norm(diff)
                if dist < 1e-12:
                    continue
                k_val = np.exp(-dist / bandwidth)
                grads[i] += alpha[j] * k_val * diff / (bandwidth * dist)
        return grads

    def compute_agop(grads):
        """Compute Average Gradient Outer Product."""
        n = grads.shape[0]
        agop = grads.T @ grads / n
        return agop

    # Choose bandwidth as median distance
    from scipy.spatial.distance import pdist
    dists = pdist(X_sub)
    bandwidth = np.median(dists)
    reg = 1e-3

    print(f"  Bandwidth: {bandwidth:.4f}, Regularization: {reg}")
    print("  Fitting kernel regression...")
    alpha = compute_kernel_regression(X_sub, y_sub, bandwidth, reg)

    print("  Computing gradients...")
    grads = compute_gradients(X_sub, alpha, bandwidth)

    print("  Computing AGOP...")
    agop = compute_agop(grads)

    # Top eigenvector
    eigenvalues, eigenvectors = np.linalg.eigh(agop)
    # eigh returns ascending order, take last
    manual_split_dir = eigenvectors[:, -1]

    print(f"  Manual top eigenvector (first 5): {manual_split_dir[:5]}")
    print(f"  Manual AGOP diagonal (first 5): {np.diag(agop)[:5]}")

    # --- Compare with xRFM library ---
    try:
        from xrfm import xRFMRegressor
        xrfm_model = xRFMRegressor(random_state=RANDOM_STATE)
        xrfm_model.fit(X_sub, y_sub)

        # Try to extract split direction from the library
        print("  xRFM model fitted successfully.")
        print("  (Library split direction extraction depends on internal API)")
    except Exception as e:
        print(f"  xRFM comparison failed: {e}")

    # Save results
    bonus_results = {
        'agop_diagonal': np.diag(agop).tolist(),
        'top_eigenvector': manual_split_dir.tolist(),
        'eigenvalues': eigenvalues.tolist(),
        'feature_names': feature_names[:X_sub.shape[1]],
    }
    with open(RESULTS_DIR / 'bonus_agop.json', 'w') as f:
        json.dump(bonus_results, f, indent=2)

    # Plot AGOP diagonal
    import matplotlib.pyplot as plt
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.bar(range(len(feature_names)), np.diag(agop), color='coral', alpha=0.8)
    ax1.set_xticks(range(len(feature_names)))
    ax1.set_xticklabels(feature_names, rotation=45, ha='right', fontsize=8)
    ax1.set_ylabel('AGOP Diagonal Value')
    ax1.set_title('Manual AGOP Diagonal (Concrete)')

    ax2.bar(range(len(feature_names)), np.abs(manual_split_dir), color='steelblue', alpha=0.8)
    ax2.set_xticks(range(len(feature_names)))
    ax2.set_xticklabels(feature_names, rotation=45, ha='right', fontsize=8)
    ax2.set_ylabel('|Eigenvector Component|')
    ax2.set_title('Top AGOP Eigenvector (Split Direction)')

    plt.tight_layout()
    plt.savefig(FIGURES_DIR / 'bonus_agop.pdf', bbox_inches='tight', dpi=150)
    plt.savefig(FIGURES_DIR / 'bonus_agop.png', bbox_inches='tight', dpi=150)
    plt.close()
    print("  Saved bonus AGOP figure.")

    return bonus_results


# ============================================================
# Generate Summary Table (LaTeX)
# ============================================================
def generate_latex_tables():
    """Generate LaTeX-formatted result tables."""
    df = pd.read_csv(RESULTS_DIR / 'main_results.csv')

    # Regression table
    reg = df[df['task'] == 'regression']
    if len(reg) > 0:
        pivot_rmse = reg.pivot(index='dataset', columns='model', values='RMSE')
        pivot_time = reg.pivot(index='dataset', columns='model', values='train_time')

        print("\n=== Regression Results (RMSE) ===")
        print(pivot_rmse.to_latex(float_format="%.4f"))

    # Classification table
    clf = df[df['task'] == 'classification']
    if len(clf) > 0:
        pivot_acc = clf.pivot(index='dataset', columns='model', values='Accuracy')
        pivot_auc = clf.pivot(index='dataset', columns='model', values='AUC-ROC')

        print("\n=== Classification Results (Accuracy) ===")
        print(pivot_acc.to_latex(float_format="%.4f"))
        print("\n=== Classification Results (AUC-ROC) ===")
        print(pivot_auc.to_latex(float_format="%.4f"))


# ============================================================
# Main
# ============================================================
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true', help='Quick test run')
    parser.add_argument('--skip-main', action='store_true')
    parser.add_argument('--skip-interp', action='store_true')
    parser.add_argument('--skip-scaling', action='store_true')
    parser.add_argument('--skip-bonus', action='store_true')
    args = parser.parse_args()

    if not args.skip_main:
        run_main_experiments(quick=args.quick)
        generate_latex_tables()

    if not args.skip_interp:
        run_interpretability_experiment()

    if not args.skip_scaling:
        run_scaling_experiment()

    if not args.skip_bonus:
        run_bonus_agop()

    print("\n" + "="*60)
    print("ALL EXPERIMENTS COMPLETE")
    print(f"Results in: {RESULTS_DIR}/")
    print(f"Figures in: {FIGURES_DIR}/")
    print("="*60)
