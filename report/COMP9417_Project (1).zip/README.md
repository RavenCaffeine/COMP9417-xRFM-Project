# COMP9417 Project: Feature Learning Kernel Machines for Tabular Data

## Group: [Your Group Name]

## Requirements

```bash
pip install xrfm xgboost scikit-learn pandas numpy matplotlib scipy optuna
```

## How to Run

### Full experiment suite
```bash
python run_experiments.py
```

### Quick test (reduced hyperparameter search)
```bash
python run_experiments.py --quick
```

### Run individual experiments
```bash
python run_experiments.py --skip-scaling --skip-bonus   # Main + interpretability only
python run_experiments.py --skip-main --skip-interp     # Scaling + bonus only
```

## Output

- `results/main_results.csv` - Main comparison table
- `results/scaling_results.csv` - Scaling experiment data
- `results/interpretability_results.csv` - Feature importance comparison
- `results/bonus_agop.json` - Bonus AGOP implementation results
- `figures/` - All plots (PDF + PNG)

## Project Structure

```
├── README.md
├── run_experiments.py      # Main experiment code (all-in-one)
├── results/                # Generated CSV/JSON results
├── figures/                # Generated plots
└── report.pdf              # Final report
```

## Datasets

All datasets are fetched from OpenML via scikit-learn. No manual download needed.

| Dataset | Task | n | d | Source |
|---------|------|-------|-----|--------|
| Adult Income | Binary classification | 48,842 | 14 | OpenML |
| Spambase | Binary classification | 4,601 | 57 | OpenML |
| Dry Bean | Multi-class classification | 13,611 | 16 | OpenML |
| Superconductivity | Regression | 21,263 | 81 | OpenML |
| Concrete Strength | Regression | 1,030 | 8 | OpenML |
| Bike Sharing | Regression | 17,379 | 12 | OpenML |

## Random Seed

All experiments use `random_state=42` for reproducibility.
